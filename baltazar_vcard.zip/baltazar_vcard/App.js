import React from 'react';
import { View, Image, ScrollView, Text, SafeAreaView, Linking, TouchableOpacity, TextInput, Button } from 'react-native';
import {GlobalStyles} from './components/style';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Card } from 'react-native-paper';
import CustomCarousel from 'carousel-with-pagination-rn';


export default function App() {

 const photoData = [
  {
    id: 1,
    index: 0,  
    imageUrl: require('./assets/photo1.jpg') ,
  },
  {
    id: 2,
    index: 1,
    imageUrl: require('./assets/photo2.jpg') ,
  },
  {
    id: 3,
    index: 2, 
    imageUrl: require('./assets/photo3.jpg') 
  },
];

  const openURL = (url) => {
    Linking.openURL(url).catch((err) => console.error("Failed to open URL:", err));
  };
  const presEmail = () => {
    const email = 'mailto:baltazar.triciamel.vegerano23@gmail.com';
    Linking.openURL(email); 
  };
  const presPhone = () => {
    const phone = 'tel:0969-425-3268';
    Linking.openURL(phone); 
  };

  const [text, onChangeText] = React.useState('');
  const [number, onChangeNumber] = React.useState('');
  const [value, onChangeMulText] = React.useState('');


  return (
    <SafeAreaView style={GlobalStyles.container}>
    <ScrollView>
     <View style={GlobalStyles.coverHeader}>
        <Image
          style={GlobalStyles.coverPhoto}
          source={require('./assets/tricia.jpg')}
        />
        <View style={GlobalStyles.profileContainer}>
          <Image
            style={GlobalStyles.profilePhoto}
            source={require('./assets/profile.jpg')}
          />
          <Text style={GlobalStyles.primaryText}>Tricia Mel V. Baltazar</Text>
          <Text style={GlobalStyles.secondaryText}>Bachelor of Science in Information Technology</Text>
        </View>
     </View>
      <View style ={GlobalStyles.introCon}>
        <Text style={GlobalStyles.introduction}> I am studying for a Bachelor of Science in Information Technology at Global Reciprocal Colleges. I am 22 years of age, and living in Guiguinto, Bulacan. I took this course because it was in demand nowadays. My hobbies are watching movies, reading manga, comics, novels, and taking pictures of nature. I am a coffee and dog lover.</Text>
      </View>
      <View style={GlobalStyles.iconCon}>
     <TouchableOpacity onPress={( ) => openURL('https://www.facebook.com/triciamel.baltazar')}>
      <Icon 
        name="facebook"
        size={25}
        color="#b01589"
        style={GlobalStyles.icon} />
    </TouchableOpacity>
    <TouchableOpacity onPress={() => openURL('https://www.instagram.com/bltzr_trish16')}>
      <Icon
      name="instagram"
      size={25}
      color="#b01589"
      style={GlobalStyles.icon} />
    </TouchableOpacity>
     </View>

     <View style={GlobalStyles.contactsCon}>
      <TouchableOpacity onPress={presEmail}>
          <Card style={GlobalStyles.contacts}>
            <Icon
              name="envelope"
              size={30}
              style={GlobalStyles.iconContacts} />
            <Text style={GlobalStyles.titleText}>baltazar.triciamel.vegerano23@gmail.com</Text>
          </Card>
      </TouchableOpacity>
      <TouchableOpacity onPress={presPhone}>
          <Card style={GlobalStyles.contacts}>
            <Icon
              name="phone"
              size={30}
              style={GlobalStyles.iconContacts} />
            <Text style={GlobalStyles.titleText}>0969-425-3268</Text>
          </Card>
      </TouchableOpacity>
     </View>
     <View style={GlobalStyles.contactsCon}>
          <Card style={GlobalStyles.contacts}>
            <Icon
              name="birthday-cake"
              size={30}
              style={GlobalStyles.iconContacts} />
            <Text style={GlobalStyles.titleText}>October 16, 2001	</Text>
          </Card>
          <Card style={GlobalStyles.contacts}>
            <Icon name="map-marker" size={30} style={GlobalStyles.iconContacts} />
            <Text style={GlobalStyles.titleText}>Guiguinto, Bulacan</Text>
          </Card>
     </View>
     
          <View style={GlobalStyles.photography}>
          <Text style={GlobalStyles.titleText2}>My Photography</Text>
            <CustomCarousel
              data={photoData}
              renderItem={({ item }) => { 
                return (
                  <View style={GlobalStyles.photography}>
                    <Image
                      source={item.imageUrl} 
                      style={GlobalStyles.photograph}
                      resizeMode='cover'
                    />
                  </View>
                );
              }}
            />
          </View>
          <View style={GlobalStyles.photography}>
            <Text style={GlobalStyles.titleText2}>My Works</Text>
            <Image
            source={require('./assets/digi1.jpg')} 
            style={GlobalStyles.digiWorks}
             />
             <Image
            source={require('./assets/digi2.jpg')} 
            style={GlobalStyles.digiWorks}
             />
             <Image
            source={require('./assets/tricia.jpg')} 
            style={GlobalStyles.digiWorks}
             />
          </View>

          <View style={GlobalStyles.inquiries}>
          <Text style={GlobalStyles.titleText2}>Inquiries</Text>
          <TextInput
              style={GlobalStyles.input}
              onChangeText={onChangeText}
              value={text}
              placeholder="Enter your Name"
            />
            <TextInput
              style={GlobalStyles.input}
              onChangeText={onChangeNumber}
              value={number}
              placeholder="Enter your Contact Number"
              keyboardType="numeric"
            />
            <TextInput
              style={GlobalStyles.inputMultiple}
              editable
              multiline
              numberOfLines={4}
              maxLength={40}
              onChangeText={text => onChangeMulText(text)}
              value={value}
              placeholder="Enter your messages"
            />
            <TouchableOpacity>
            <Button
              title="Send Inquiries"
              color='#b01589'
            />
            </TouchableOpacity>
          </View>

     </ScrollView>
    </SafeAreaView>
  );
}
