export const GlobalStyles = {
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#fcf0f7',
  },
  primaryText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 10
  },
  secondaryText: {
    fontSize: 14,
    color: 'gray',
  },
  coverHeader: {
    alignItems: 'center',
  },
  coverPhoto: {
    width: '100%',
    height: 180,
  },
  profileContainer: {
    alignItems: 'center',
    marginTop: -70,
  },
  profilePhoto: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderColor: '#fcf0f7' ,
    borderWidth: 5,
  },
  
  introCon: {
    padding: 10,
  },
  introduction: {
    marginHorizontal: 20,
    textAlign: 'center',
    fontSize: 12,
  },
  iconCon: {
    flexDirection: 'row', 
    justifyContent: 'center', 
    alignItems: 'center', 
    flex: 1,
  },
  icon: {
    margin: 10, 
    backgroundColor: 'white',
    borderRadius: 40,
    borderColor: '#b01589',
    borderWidth: 2,
    padding: 10,
    justifyContent: 'center', 
    alignItems: 'center', 
    width: '65%',
    height: '65%'
  },
  contactsCon:{
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row', 
  },
  contacts:{
    width: 180,
    height: 90, 
    margin: 5,
    backgroundColor: '#e77baf',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  titleText: {
    fontSize: 14,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 5,
  },
  iconContacts: {
    color: 'white',
    fontWeight: 'bold',
    marginTop: 10,
    textAlign: 'center'
  },
  photography: {
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
   titleText2: {
    fontSize: 18,
    color:'white',
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 5,
    marginTop: 15,
    backgroundColor: '#e77baf',
    borderRadius: 10,
    borderColor: '#e77baf',
    borderWidth: 2,
  },
  photograph: {
    width: 300, 
    height: 200,
    margin: 3
  },
  photoCon: {
    marginLeft: 15,
  },
  digiWorks: {
    width: '100%', 
    height: 200,
  },
  inquiries:{
      marginTop: 20,
      padding: 10,
      backgroundColor: '#e77baf'
  },
  input: {
    height: 40,
    margin: 8,
    borderWidth: 2,
    padding: 10,
    borderRadius: 10,
    borderColor: '#b01589',
    backgroundColor: 'white',
  },
  inputMultiple: {
    margin: 8,
    borderWidth: 2,
    padding: 10,
    borderRadius: 10,
    borderColor: '#b01589',
    backgroundColor: 'white',
  },
};